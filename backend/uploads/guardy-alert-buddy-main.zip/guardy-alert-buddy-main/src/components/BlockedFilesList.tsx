import { Shield, AlertTriangle, Clock } from 'lucide-react';
import { BlockedFile, formatFileSize } from '@/lib/fileBlocker';

interface BlockedFilesListProps {
  files: BlockedFile[];
}

const threatBadge: Record<string, string> = {
  critical: 'bg-threat-critical/20 text-threat-critical border-threat-critical/30',
  high: 'bg-threat-high/20 text-threat-high border-threat-high/30',
  medium: 'bg-threat-medium/20 text-threat-medium border-threat-medium/30',
  low: 'bg-threat-low/20 text-threat-low border-threat-low/30',
};

const statusIcon: Record<string, typeof Shield> = {
  blocked: Shield,
  quarantined: AlertTriangle,
  reviewed: Clock,
};

function timeAgo(date: Date): string {
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
  if (seconds < 60) return `${seconds}s ago`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  return `${Math.floor(seconds / 3600)}h ago`;
}

export function BlockedFilesList({ files }: BlockedFilesListProps) {
  return (
    <div className="rounded-lg border border-glow bg-card">
      <div className="border-b border-border px-5 py-4">
        <h2 className="font-semibold text-foreground flex items-center gap-2">
          <Shield className="h-4 w-4 text-destructive animate-pulse-glow" />
          Blocked Files Log
        </h2>
      </div>
      <div className="divide-y divide-border">
        {files.length === 0 && (
          <div className="px-5 py-8 text-center text-muted-foreground text-sm">No blocked files yet</div>
        )}
        {files.map((file) => {
          const StatusIcon = statusIcon[file.status] || Shield;
          return (
            <div key={file.id} className="px-5 py-3 hover:bg-accent/50 transition-colors animate-slide-in-right">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 min-w-0">
                  <StatusIcon className="h-4 w-4 text-destructive shrink-0" />
                  <div className="min-w-0">
                    <p className="font-mono text-sm font-medium text-foreground truncate">{file.fileName}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      From: <span className={file.senderType === 'unknown' ? 'text-threat-high' : 'text-foreground'}>{file.sender}</span>
                      {' · '}{formatFileSize(file.fileSize)}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <span className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-mono font-semibold uppercase tracking-wider ${threatBadge[file.threatLevel]}`}>
                    {file.threatLevel}
                  </span>
                  <span className="text-[10px] text-muted-foreground font-mono w-14 text-right">{timeAgo(file.blockedAt)}</span>
                </div>
              </div>
              <p className="mt-1 ml-7 text-xs text-muted-foreground">{file.reason}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}
