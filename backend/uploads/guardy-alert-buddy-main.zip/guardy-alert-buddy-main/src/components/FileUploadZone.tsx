import { useState, useCallback } from 'react';
import { Upload, ShieldAlert } from 'lucide-react';
import { analyzeFile, BlockedFile } from '@/lib/fileBlocker';
import { toast } from 'sonner';

interface FileUploadZoneProps {
  onFileBlocked: (file: BlockedFile) => void;
}

export function FileUploadZone({ onFileBlocked }: FileUploadZoneProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [senderEmail, setSenderEmail] = useState('');

  const handleFile = useCallback((file: File) => {
    setScanning(true);
    const sender = senderEmail || 'unknown@unverified.net';
    const { threatLevel, reason } = analyzeFile(file, senderEmail ? 'known' : '');

    // Simulate scan delay
    setTimeout(() => {
      const blockedFile: BlockedFile = {
        id: Date.now().toString(),
        fileName: file.name,
        fileType: '.' + (file.name.split('.').pop() || 'unknown'),
        fileSize: file.size,
        sender,
        senderType: senderEmail ? 'known' : 'unknown',
        threatLevel,
        reason,
        blockedAt: new Date(),
        status: threatLevel === 'critical' ? 'blocked' : 'quarantined',
      };

      onFileBlocked(blockedFile);
      setScanning(false);

      // Alert notification
      toast.error(`🚨 FILE BLOCKED: ${file.name}`, {
        description: `Threat: ${threatLevel.toUpperCase()} — ${reason}`,
        duration: 6000,
      });
    }, 800);
  }, [senderEmail, onFileBlocked]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  }, [handleFile]);

  return (
    <div className="rounded-lg border border-glow bg-card p-5">
      <h2 className="font-semibold text-foreground mb-4 flex items-center gap-2">
        <ShieldAlert className="h-4 w-4 text-primary" />
        Simulate Incoming File
      </h2>

      <div className="mb-3">
        <label className="text-xs text-muted-foreground uppercase tracking-wider font-medium">Sender Email (leave empty for unknown)</label>
        <input
          type="email"
          value={senderEmail}
          onChange={(e) => setSenderEmail(e.target.value)}
          placeholder="unknown@suspicious.net"
          className="mt-1 w-full rounded-md border border-border bg-background px-3 py-2 text-sm font-mono text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
        />
      </div>

      <div
        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        className={`relative mt-2 flex flex-col items-center justify-center rounded-lg border-2 border-dashed p-8 transition-all cursor-pointer
          ${isDragging ? 'border-primary bg-primary/5 glow-primary' : 'border-border hover:border-primary/50'}
          ${scanning ? 'pointer-events-none' : ''}
        `}
        onClick={() => document.getElementById('file-input')?.click()}
      >
        {scanning ? (
          <div className="flex flex-col items-center gap-2">
            <div className="relative h-10 w-10">
              <ShieldAlert className="h-10 w-10 text-destructive animate-pulse-glow" />
            </div>
            <p className="font-mono text-sm text-destructive font-semibold">SCANNING & BLOCKING...</p>
            <div className="h-1 w-32 rounded-full bg-secondary overflow-hidden">
              <div className="h-full bg-destructive rounded-full animate-scan-line" style={{ width: '100%' }} />
            </div>
          </div>
        ) : (
          <>
            <Upload className="h-8 w-8 text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">
              <span className="text-primary font-medium">Click to upload</span> or drag & drop
            </p>
            <p className="text-xs text-muted-foreground mt-1">All files will be immediately blocked & analyzed</p>
          </>
        )}
        <input id="file-input" type="file" className="hidden" onChange={handleInputChange} />
      </div>
    </div>
  );
}
