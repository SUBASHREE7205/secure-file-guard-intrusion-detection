import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import { Activity } from "lucide-react";

interface AppLayoutProps {
  children: React.ReactNode;
  totalThreats?: number;
}

export function AppLayout({ children, totalThreats = 0 }: AppLayoutProps) {
  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-background">
        <AppSidebar />
        <div className="flex-1 flex flex-col min-w-0">
          <header className="h-12 flex items-center justify-between border-b border-border bg-card/80 backdrop-blur-md sticky top-0 z-10 px-4">
            <SidebarTrigger className="text-muted-foreground hover:text-foreground" />
            <div className="flex items-center gap-3">
              {totalThreats > 0 && (
                <div className="hidden sm:flex items-center gap-2 text-xs text-muted-foreground font-mono bg-accent/50 rounded-md px-3 py-1.5">
                  <Activity className="h-3 w-3 text-primary" />
                  <span>{totalThreats} threats detected</span>
                </div>
              )}
              <div className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-success animate-pulse" />
                <span className="text-xs text-muted-foreground font-mono">Active</span>
              </div>
            </div>
          </header>
          <main className="flex-1 overflow-auto">
            {children}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
