import { Bell, X } from 'lucide-react';
import { AlertMessage } from '@/lib/fileBlocker';

interface AlertPanelProps {
  alerts: AlertMessage[];
  onDismiss: (id: string) => void;
}

const threatColor: Record<string, string> = {
  critical: 'border-l-threat-critical bg-threat-critical/5',
  high: 'border-l-threat-high bg-threat-high/5',
  medium: 'border-l-threat-medium bg-threat-medium/5',
  low: 'border-l-threat-low bg-threat-low/5',
};

export function AlertPanel({ alerts, onDismiss }: AlertPanelProps) {
  const unread = alerts.filter(a => !a.read);

  return (
    <div className="rounded-lg border border-glow bg-card">
      <div className="border-b border-border px-5 py-4 flex items-center justify-between">
        <h2 className="font-semibold text-foreground flex items-center gap-2">
          <Bell className="h-4 w-4 text-warning" />
          Admin Alerts
          {unread.length > 0 && (
            <span className="inline-flex items-center justify-center h-5 min-w-[20px] rounded-full bg-destructive px-1.5 text-[10px] font-bold text-destructive-foreground">
              {unread.length}
            </span>
          )}
        </h2>
      </div>
      <div className="max-h-64 overflow-y-auto divide-y divide-border">
        {alerts.length === 0 && (
          <div className="px-5 py-6 text-center text-muted-foreground text-sm">No alerts</div>
        )}
        {alerts.map(alert => (
          <div key={alert.id} className={`px-5 py-3 border-l-2 flex items-start justify-between gap-2 animate-slide-in-right ${threatColor[alert.threatLevel]}`}>
            <div className="min-w-0">
              <p className="text-sm text-foreground font-medium">{alert.message}</p>
              <p className="text-[10px] text-muted-foreground font-mono mt-0.5">
                {alert.timestamp.toLocaleTimeString()}
              </p>
            </div>
            <button onClick={() => onDismiss(alert.id)} className="shrink-0 p-1 rounded hover:bg-accent transition-colors">
              <X className="h-3 w-3 text-muted-foreground" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
