import { Activity, ShieldBan, ShieldAlert, Clock } from 'lucide-react';
import { BlockedFile, formatFileSize } from '@/lib/fileBlocker';

interface RecentActivityProps {
  files: BlockedFile[];
}

const threatIcon = {
  critical: ShieldBan,
  high: ShieldAlert,
  medium: ShieldAlert,
  low: Clock,
};

const dotColor: Record<string, string> = {
  critical: 'bg-[hsl(0,72%,51%)]',
  high: 'bg-[hsl(25,95%,53%)]',
  medium: 'bg-[hsl(38,92%,50%)]',
  low: 'bg-primary',
};

function timeAgo(date: Date): string {
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
  if (seconds < 60) return `${seconds}s ago`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  return `${Math.floor(seconds / 3600)}h ago`;
}

export function RecentActivity({ files }: RecentActivityProps) {
  const recent = files.slice(0, 5);

  return (
    <div className="rounded-lg border border-glow bg-card">
      <div className="border-b border-border px-5 py-4 flex items-center gap-2">
        <Activity className="h-4 w-4 text-primary" />
        <h2 className="font-semibold text-foreground text-sm">Recent Activity</h2>
      </div>
      <div className="p-4">
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-[7px] top-2 bottom-2 w-px bg-border" />
          <div className="space-y-4">
            {recent.map((file) => {
              const Icon = threatIcon[file.threatLevel] || ShieldAlert;
              return (
                <div key={file.id} className="flex gap-3 relative animate-slide-in-right">
                  <div className={`relative z-10 mt-1 h-3.5 w-3.5 rounded-full border-2 border-card ${dotColor[file.threatLevel]}`} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <Icon className="h-3 w-3 text-muted-foreground shrink-0" />
                      <span className="text-xs font-mono font-medium text-foreground truncate">{file.fileName}</span>
                    </div>
                    <p className="text-[10px] text-muted-foreground mt-0.5">
                      {file.reason} · {formatFileSize(file.fileSize)} · {timeAgo(file.blockedAt)}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
