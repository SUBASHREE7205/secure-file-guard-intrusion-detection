import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { BlockedFile } from '@/lib/fileBlocker';

interface ThreatChartProps {
  files: BlockedFile[];
}

const THREAT_COLORS = {
  critical: 'hsl(0, 72%, 51%)',
  high: 'hsl(25, 95%, 53%)',
  medium: 'hsl(38, 92%, 50%)',
  low: 'hsl(199, 89%, 48%)',
};

const LABELS: Record<string, string> = {
  critical: 'Critical',
  high: 'High',
  medium: 'Medium',
  low: 'Low',
};

export function ThreatChart({ files }: ThreatChartProps) {
  const counts = files.reduce((acc, f) => {
    acc[f.threatLevel] = (acc[f.threatLevel] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const data = Object.entries(counts).map(([level, count]) => ({
    name: LABELS[level] || level,
    value: count,
    color: THREAT_COLORS[level as keyof typeof THREAT_COLORS] || '#888',
  }));

  if (data.length === 0) return null;

  return (
    <div className="rounded-lg border border-glow bg-card p-5">
      <h2 className="font-semibold text-foreground text-sm mb-4 uppercase tracking-widest">Threat Distribution</h2>
      <div className="flex items-center gap-4">
        <div className="w-36 h-36">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={35}
                outerRadius={60}
                paddingAngle={3}
                dataKey="value"
                stroke="none"
              >
                {data.map((entry, i) => (
                  <Cell key={i} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  background: 'hsl(222, 44%, 9%)',
                  border: '1px solid hsl(222, 30%, 18%)',
                  borderRadius: '8px',
                  color: 'hsl(210, 40%, 92%)',
                  fontSize: '12px',
                  fontFamily: 'JetBrains Mono, monospace',
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="flex flex-col gap-2">
          {data.map((item) => (
            <div key={item.name} className="flex items-center gap-2">
              <div className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: item.color }} />
              <span className="text-xs text-muted-foreground font-mono">
                {item.name}: <span className="text-foreground font-semibold">{item.value}</span>
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
