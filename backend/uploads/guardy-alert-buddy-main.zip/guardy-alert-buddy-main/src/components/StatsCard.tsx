import { LucideIcon } from 'lucide-react';

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  trend?: string;
  variant?: 'default' | 'danger' | 'warning' | 'success';
}

const variantStyles = {
  default: 'border-glow glow-primary',
  danger: 'border-destructive/30 glow-danger',
  warning: 'border-warning/30 glow-warning',
  success: 'border-success/30',
};

const iconVariantStyles = {
  default: 'text-primary bg-primary/10',
  danger: 'text-destructive bg-destructive/10',
  warning: 'text-warning bg-warning/10',
  success: 'text-success bg-success/10',
};

const valueVariantStyles = {
  default: 'text-primary',
  danger: 'text-destructive',
  warning: 'text-warning',
  success: 'text-success',
};

export function StatsCard({ title, value, icon: Icon, trend, variant = 'default' }: StatsCardProps) {
  return (
    <div className={`group rounded-lg border bg-card p-5 transition-all duration-300 hover:scale-[1.03] hover:shadow-lg ${variantStyles[variant]}`}>
      <div className="flex items-center justify-between mb-3">
        <span className="text-[10px] font-semibold uppercase tracking-[0.15em] text-muted-foreground">{title}</span>
        <div className={`h-8 w-8 rounded-md flex items-center justify-center transition-transform group-hover:scale-110 ${iconVariantStyles[variant]}`}>
          <Icon className="h-4 w-4" />
        </div>
      </div>
      <div className={`font-mono text-3xl font-bold tracking-tight ${valueVariantStyles[variant]}`}>{value}</div>
      {trend && (
        <p className="mt-2 text-[10px] text-muted-foreground font-medium tracking-wide">{trend}</p>
      )}
    </div>
  );
}
