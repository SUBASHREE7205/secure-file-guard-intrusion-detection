import { useState } from 'react';
import { AppLayout } from '@/components/AppLayout';
import { generateDemoData, formatFileSize, BlockedFile } from '@/lib/fileBlocker';
import { Search, FolderLock, Shield, AlertTriangle, Clock, Eye, Trash2, RotateCcw } from 'lucide-react';

const threatBadge: Record<string, string> = {
  critical: 'bg-threat-critical/20 text-threat-critical border-threat-critical/30',
  high: 'bg-threat-high/20 text-threat-high border-threat-high/30',
  medium: 'bg-threat-medium/20 text-threat-medium border-threat-medium/30',
  low: 'bg-threat-low/20 text-threat-low border-threat-low/30',
};

const statusBadge: Record<string, string> = {
  blocked: 'bg-destructive/10 text-destructive',
  quarantined: 'bg-warning/10 text-warning',
  reviewed: 'bg-primary/10 text-primary',
};

const FileManagement = () => {
  const [files, setFiles] = useState<BlockedFile[]>(generateDemoData());
  const [search, setSearch] = useState('');
  const [filterThreat, setFilterThreat] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const filtered = files.filter(f => {
    const matchSearch = f.fileName.toLowerCase().includes(search.toLowerCase()) || f.sender.toLowerCase().includes(search.toLowerCase());
    const matchThreat = filterThreat === 'all' || f.threatLevel === filterThreat;
    const matchStatus = filterStatus === 'all' || f.status === filterStatus;
    return matchSearch && matchThreat && matchStatus;
  });

  const updateStatus = (id: string, status: BlockedFile['status']) => {
    setFiles(prev => prev.map(f => f.id === id ? { ...f, status } : f));
  };

  const deleteFile = (id: string) => {
    setFiles(prev => prev.filter(f => f.id !== id));
  };

  return (
    <AppLayout totalThreats={files.length}>
      <div className="container px-4 py-6 space-y-6">
        <div>
          <h1 className="text-xl font-bold text-foreground flex items-center gap-2">
            <FolderLock className="h-5 w-5 text-primary" />
            File Management
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Browse, search, and manage all blocked files</p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search files or senders..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-md border border-border bg-background text-sm font-mono text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
            />
          </div>
          <select
            value={filterThreat}
            onChange={(e) => setFilterThreat(e.target.value)}
            className="rounded-md border border-border bg-background px-3 py-2 text-sm font-mono text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
          >
            <option value="all">All Threats</option>
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="rounded-md border border-border bg-background px-3 py-2 text-sm font-mono text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
          >
            <option value="all">All Status</option>
            <option value="blocked">Blocked</option>
            <option value="quarantined">Quarantined</option>
            <option value="reviewed">Reviewed</option>
          </select>
        </div>

        {/* Results count */}
        <p className="text-xs text-muted-foreground font-mono">
          Showing {filtered.length} of {files.length} files
        </p>

        {/* File Table */}
        <div className="rounded-lg border border-glow bg-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border text-[10px] font-semibold uppercase tracking-[0.15em] text-muted-foreground">
                  <th className="text-left px-4 py-3">File</th>
                  <th className="text-left px-4 py-3">Sender</th>
                  <th className="text-left px-4 py-3">Size</th>
                  <th className="text-left px-4 py-3">Threat</th>
                  <th className="text-left px-4 py-3">Status</th>
                  <th className="text-right px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map(file => (
                  <tr key={file.id} className="hover:bg-accent/30 transition-colors">
                    <td className="px-4 py-3">
                      <p className="font-mono text-sm font-medium text-foreground">{file.fileName}</p>
                      <p className="text-[10px] text-muted-foreground">{file.reason}</p>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs font-mono ${file.senderType === 'unknown' ? 'text-threat-high' : 'text-foreground'}`}>
                        {file.sender}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs font-mono text-muted-foreground">
                      {formatFileSize(file.fileSize)}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[10px] font-mono font-semibold uppercase tracking-wider ${threatBadge[file.threatLevel]}`}>
                        {file.threatLevel}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-mono font-semibold capitalize ${statusBadge[file.status]}`}>
                        {file.status}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          onClick={() => updateStatus(file.id, 'reviewed')}
                          className="p-1.5 rounded hover:bg-accent transition-colors"
                          title="Mark reviewed"
                        >
                          <Eye className="h-3.5 w-3.5 text-primary" />
                        </button>
                        <button
                          onClick={() => updateStatus(file.id, 'quarantined')}
                          className="p-1.5 rounded hover:bg-accent transition-colors"
                          title="Quarantine"
                        >
                          <RotateCcw className="h-3.5 w-3.5 text-warning" />
                        </button>
                        <button
                          onClick={() => deleteFile(file.id)}
                          className="p-1.5 rounded hover:bg-destructive/10 transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="h-3.5 w-3.5 text-destructive" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-4 py-8 text-center text-sm text-muted-foreground">
                      No files match your filters
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </AppLayout>
  );
};

export default FileManagement;
