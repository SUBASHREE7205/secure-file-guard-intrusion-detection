import { AppLayout } from '@/components/AppLayout';
import { generateDemoData } from '@/lib/fileBlocker';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Calendar, ShieldAlert } from 'lucide-react';

const demoFiles = generateDemoData();

const threatOverTime = [
  { time: '00:00', critical: 1, high: 2, medium: 1, low: 3 },
  { time: '04:00', critical: 0, high: 1, medium: 3, low: 2 },
  { time: '08:00', critical: 2, high: 3, medium: 2, low: 1 },
  { time: '12:00', critical: 3, high: 2, medium: 4, low: 2 },
  { time: '16:00', critical: 1, high: 4, medium: 2, low: 3 },
  { time: '20:00', critical: 2, high: 1, medium: 1, low: 1 },
];

const fileTypes = [
  { name: '.exe', count: 12, color: 'hsl(0, 72%, 51%)' },
  { name: '.zip', count: 8, color: 'hsl(25, 95%, 53%)' },
  { name: '.docm', count: 5, color: 'hsl(38, 92%, 50%)' },
  { name: '.bat', count: 3, color: 'hsl(199, 89%, 48%)' },
  { name: '.pptx', count: 2, color: 'hsl(215, 20%, 55%)' },
];

const weeklyTrend = [
  { day: 'Mon', blocked: 8 },
  { day: 'Tue', blocked: 12 },
  { day: 'Wed', blocked: 6 },
  { day: 'Thu', blocked: 15 },
  { day: 'Fri', blocked: 10 },
  { day: 'Sat', blocked: 3 },
  { day: 'Sun', blocked: 2 },
];

const tooltipStyle = {
  contentStyle: {
    background: 'hsl(222, 44%, 9%)',
    border: '1px solid hsl(222, 30%, 18%)',
    borderRadius: '8px',
    color: 'hsl(210, 40%, 92%)',
    fontSize: '12px',
    fontFamily: 'JetBrains Mono, monospace',
  },
};

const Analytics = () => {
  return (
    <AppLayout totalThreats={demoFiles.length}>
      <div className="container px-4 py-6 space-y-6">
        <div>
          <h1 className="text-xl font-bold text-foreground flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-primary" />
            Analytics & Reports
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Threat intelligence and trend analysis</p>
        </div>

        {/* Threats over time */}
        <div className="rounded-lg border border-glow bg-card p-5">
          <h2 className="text-sm font-semibold text-foreground uppercase tracking-widest mb-4 flex items-center gap-2">
            <ShieldAlert className="h-4 w-4 text-destructive" />
            Threats by Time of Day
          </h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={threatOverTime}>
                <XAxis dataKey="time" tick={{ fill: 'hsl(215, 20%, 55%)', fontSize: 11, fontFamily: 'JetBrains Mono' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: 'hsl(215, 20%, 55%)', fontSize: 11, fontFamily: 'JetBrains Mono' }} axisLine={false} tickLine={false} />
                <Tooltip {...tooltipStyle} />
                <Bar dataKey="critical" stackId="a" fill="hsl(0, 72%, 51%)" radius={[0, 0, 0, 0]} />
                <Bar dataKey="high" stackId="a" fill="hsl(25, 95%, 53%)" />
                <Bar dataKey="medium" stackId="a" fill="hsl(38, 92%, 50%)" />
                <Bar dataKey="low" stackId="a" fill="hsl(199, 89%, 48%)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Weekly trend */}
          <div className="rounded-lg border border-glow bg-card p-5">
            <h2 className="text-sm font-semibold text-foreground uppercase tracking-widest mb-4 flex items-center gap-2">
              <Calendar className="h-4 w-4 text-primary" />
              Weekly Trend
            </h2>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={weeklyTrend}>
                  <XAxis dataKey="day" tick={{ fill: 'hsl(215, 20%, 55%)', fontSize: 11, fontFamily: 'JetBrains Mono' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: 'hsl(215, 20%, 55%)', fontSize: 11, fontFamily: 'JetBrains Mono' }} axisLine={false} tickLine={false} />
                  <Tooltip {...tooltipStyle} />
                  <Line type="monotone" dataKey="blocked" stroke="hsl(199, 89%, 48%)" strokeWidth={2} dot={{ fill: 'hsl(199, 89%, 48%)', r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* File type distribution */}
          <div className="rounded-lg border border-glow bg-card p-5">
            <h2 className="text-sm font-semibold text-foreground uppercase tracking-widest mb-4">
              Blocked File Types
            </h2>
            <div className="flex items-center gap-4">
              <div className="w-40 h-40">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={fileTypes} cx="50%" cy="50%" innerRadius={35} outerRadius={60} paddingAngle={3} dataKey="count" stroke="none">
                      {fileTypes.map((entry, i) => (
                        <Cell key={i} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip {...tooltipStyle} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex flex-col gap-2">
                {fileTypes.map((item) => (
                  <div key={item.name} className="flex items-center gap-2">
                    <div className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                    <span className="text-xs text-muted-foreground font-mono">
                      {item.name}: <span className="text-foreground font-semibold">{item.count}</span>
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
};

export default Analytics;
