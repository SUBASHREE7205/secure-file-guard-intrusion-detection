import { useState } from 'react';
import { AppLayout } from '@/components/AppLayout';
import { Settings as SettingsIcon, Mail, Shield, Bell, Save } from 'lucide-react';
import { toast } from 'sonner';

const Settings = () => {
  const [adminEmail, setAdminEmail] = useState('');
  const [emailEnabled, setEmailEnabled] = useState(false);
  const [autoBlock, setAutoBlock] = useState(true);
  const [quarantineUnknown, setQuarantineUnknown] = useState(true);
  const [notifyCritical, setNotifyCritical] = useState(true);
  const [notifyHigh, setNotifyHigh] = useState(true);
  const [notifyMedium, setNotifyMedium] = useState(false);

  const handleSave = () => {
    toast.success('Settings saved successfully');
  };

  return (
    <AppLayout>
      <div className="container px-4 py-6 space-y-6 max-w-2xl">
        <div>
          <h1 className="text-xl font-bold text-foreground flex items-center gap-2">
            <SettingsIcon className="h-5 w-5 text-primary" />
            Settings
          </h1>
          <p className="text-sm text-muted-foreground mt-1">Configure security rules and notifications</p>
        </div>

        {/* Email Alerts */}
        <div className="rounded-lg border border-glow bg-card p-5 space-y-4">
          <h2 className="text-sm font-semibold text-foreground uppercase tracking-widest flex items-center gap-2">
            <Mail className="h-4 w-4 text-primary" />
            Email Alerts
          </h2>
          <div className="space-y-3">
            <div>
              <label className="text-xs text-muted-foreground uppercase tracking-wider font-medium">Admin Email</label>
              <input
                type="email"
                value={adminEmail}
                onChange={(e) => setAdminEmail(e.target.value)}
                placeholder="admin@company.com"
                className="mt-1 w-full rounded-md border border-border bg-background px-3 py-2 text-sm font-mono text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
            <label className="flex items-center gap-3 cursor-pointer">
              <button
                onClick={() => setEmailEnabled(!emailEnabled)}
                className={`h-5 w-9 rounded-full transition-colors relative ${emailEnabled ? 'bg-primary' : 'bg-secondary'}`}
              >
                <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-foreground transition-transform ${emailEnabled ? 'translate-x-4' : 'translate-x-0.5'}`} />
              </button>
              <span className="text-sm text-foreground">Enable email alerts</span>
            </label>
          </div>
        </div>

        {/* Security Rules */}
        <div className="rounded-lg border border-glow bg-card p-5 space-y-4">
          <h2 className="text-sm font-semibold text-foreground uppercase tracking-widest flex items-center gap-2">
            <Shield className="h-4 w-4 text-destructive" />
            Security Rules
          </h2>
          <div className="space-y-3">
            <label className="flex items-center gap-3 cursor-pointer">
              <button
                onClick={() => setAutoBlock(!autoBlock)}
                className={`h-5 w-9 rounded-full transition-colors relative ${autoBlock ? 'bg-primary' : 'bg-secondary'}`}
              >
                <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-foreground transition-transform ${autoBlock ? 'translate-x-4' : 'translate-x-0.5'}`} />
              </button>
              <span className="text-sm text-foreground">Auto-block executable files</span>
            </label>
            <label className="flex items-center gap-3 cursor-pointer">
              <button
                onClick={() => setQuarantineUnknown(!quarantineUnknown)}
                className={`h-5 w-9 rounded-full transition-colors relative ${quarantineUnknown ? 'bg-primary' : 'bg-secondary'}`}
              >
                <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-foreground transition-transform ${quarantineUnknown ? 'translate-x-4' : 'translate-x-0.5'}`} />
              </button>
              <span className="text-sm text-foreground">Quarantine files from unknown senders</span>
            </label>
          </div>
        </div>

        {/* Notification Preferences */}
        <div className="rounded-lg border border-glow bg-card p-5 space-y-4">
          <h2 className="text-sm font-semibold text-foreground uppercase tracking-widest flex items-center gap-2">
            <Bell className="h-4 w-4 text-warning" />
            Notification Preferences
          </h2>
          <div className="space-y-3">
            {[
              { label: 'Critical threats', checked: notifyCritical, toggle: () => setNotifyCritical(!notifyCritical) },
              { label: 'High threats', checked: notifyHigh, toggle: () => setNotifyHigh(!notifyHigh) },
              { label: 'Medium threats', checked: notifyMedium, toggle: () => setNotifyMedium(!notifyMedium) },
            ].map(({ label, checked, toggle }) => (
              <label key={label} className="flex items-center gap-3 cursor-pointer">
                <button
                  onClick={toggle}
                  className={`h-5 w-9 rounded-full transition-colors relative ${checked ? 'bg-primary' : 'bg-secondary'}`}
                >
                  <span className={`absolute top-0.5 h-4 w-4 rounded-full bg-foreground transition-transform ${checked ? 'translate-x-4' : 'translate-x-0.5'}`} />
                </button>
                <span className="text-sm text-foreground">Notify on {label.toLowerCase()}</span>
              </label>
            ))}
          </div>
        </div>

        <button
          onClick={handleSave}
          className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 transition-colors"
        >
          <Save className="h-4 w-4" />
          Save Settings
        </button>
      </div>
    </AppLayout>
  );
};

export default Settings;
