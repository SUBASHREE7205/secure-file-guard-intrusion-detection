import { useState, useCallback } from 'react';
import { Shield, ShieldAlert, ShieldBan, Users } from 'lucide-react';
import { BlockedFile, AlertMessage, generateDemoData } from '@/lib/fileBlocker';
import { StatsCard } from '@/components/StatsCard';
import { BlockedFilesList } from '@/components/BlockedFilesList';
import { FileUploadZone } from '@/components/FileUploadZone';
import { AlertPanel } from '@/components/AlertPanel';
import { ThreatChart } from '@/components/ThreatChart';
import { RecentActivity } from '@/components/RecentActivity';
import { AppLayout } from '@/components/AppLayout';

const Index = () => {
  const [blockedFiles, setBlockedFiles] = useState<BlockedFile[]>(generateDemoData());
  const [alerts, setAlerts] = useState<AlertMessage[]>([]);

  const handleFileBlocked = useCallback((file: BlockedFile) => {
    setBlockedFiles(prev => [file, ...prev]);
    const alert: AlertMessage = {
      id: Date.now().toString(),
      fileId: file.id,
      message: `🚨 ${file.fileName} blocked — ${file.threatLevel.toUpperCase()} threat from ${file.sender}`,
      threatLevel: file.threatLevel,
      timestamp: new Date(),
      read: false,
    };
    setAlerts(prev => [alert, ...prev]);
  }, []);

  const dismissAlert = useCallback((id: string) => {
    setAlerts(prev => prev.filter(a => a.id !== id));
  }, []);

  const criticalCount = blockedFiles.filter(f => f.threatLevel === 'critical').length;
  const highCount = blockedFiles.filter(f => f.threatLevel === 'high').length;
  const unknownCount = blockedFiles.filter(f => f.senderType === 'unknown').length;

  return (
    <AppLayout totalThreats={blockedFiles.length}>
      <div className="container px-4 py-6 space-y-6">
        {/* Stats Row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          <StatsCard title="Total Blocked" value={blockedFiles.length} icon={Shield} variant="default" trend="All incoming files" />
          <StatsCard title="Critical" value={criticalCount} icon={ShieldBan} variant="danger" trend="Immediate action needed" />
          <StatsCard title="High Risk" value={highCount} icon={ShieldAlert} variant="warning" trend="Requires investigation" />
          <StatsCard title="Unknown Senders" value={unknownCount} icon={Users} variant="default" trend="Unverified sources" />
        </div>

        {/* Chart + Activity Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <ThreatChart files={blockedFiles} />
          <RecentActivity files={blockedFiles} />
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <BlockedFilesList files={blockedFiles} />
          </div>
          <div className="space-y-6">
            <FileUploadZone onFileBlocked={handleFileBlocked} />
            <AlertPanel alerts={alerts} onDismiss={dismissAlert} />
          </div>
        </div>
      </div>
    </AppLayout>
  );
};

export default Index;
