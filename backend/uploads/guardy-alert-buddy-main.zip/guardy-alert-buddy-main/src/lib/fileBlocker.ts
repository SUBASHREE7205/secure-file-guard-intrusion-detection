export type ThreatLevel = 'critical' | 'high' | 'medium' | 'low';

export interface BlockedFile {
  id: string;
  fileName: string;
  fileType: string;
  fileSize: number;
  sender: string;
  senderType: 'known' | 'unknown';
  threatLevel: ThreatLevel;
  reason: string;
  blockedAt: Date;
  status: 'blocked' | 'quarantined' | 'reviewed';
}

export interface AlertMessage {
  id: string;
  fileId: string;
  message: string;
  threatLevel: ThreatLevel;
  timestamp: Date;
  read: boolean;
}

const DANGEROUS_EXTENSIONS = ['.exe', '.bat', '.sh', '.cmd', '.ps1', '.vbs', '.js', '.msi', '.dll', '.scr', '.pif'];
const SUSPICIOUS_EXTENSIONS = ['.zip', '.rar', '.7z', '.tar', '.iso', '.img'];
const MODERATE_EXTENSIONS = ['.docm', '.xlsm', '.pptm', '.jar', '.py'];

export function analyzeFile(file: File, sender: string): { threatLevel: ThreatLevel; reason: string } {
  const ext = '.' + file.name.split('.').pop()?.toLowerCase();
  
  if (DANGEROUS_EXTENSIONS.includes(ext)) {
    return { threatLevel: 'critical', reason: `Executable file type (${ext}) — immediate threat` };
  }
  if (SUSPICIOUS_EXTENSIONS.includes(ext)) {
    return { threatLevel: 'high', reason: `Archive/disk image (${ext}) — may contain malware` };
  }
  if (MODERATE_EXTENSIONS.includes(ext)) {
    return { threatLevel: 'medium', reason: `Macro-enabled document (${ext}) — potential threat` };
  }
  if (file.size > 50 * 1024 * 1024) {
    return { threatLevel: 'medium', reason: 'Unusually large file size — suspicious payload' };
  }
  if (sender === 'unknown' || !sender) {
    return { threatLevel: 'high', reason: 'File from unverified/unknown sender' };
  }
  return { threatLevel: 'low', reason: 'File blocked per security policy — all files require review' };
}

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

// Generate demo data
export function generateDemoData(): BlockedFile[] {
  const demoFiles: BlockedFile[] = [
    {
      id: '1', fileName: 'update_v2.exe', fileType: '.exe', fileSize: 2340000,
      sender: 'unknown@suspicious.net', senderType: 'unknown', threatLevel: 'critical',
      reason: 'Executable file type (.exe) — immediate threat', blockedAt: new Date(Date.now() - 120000), status: 'blocked'
    },
    {
      id: '2', fileName: 'invoice_march.zip', fileType: '.zip', fileSize: 890000,
      sender: 'billing@vendor.com', senderType: 'known', threatLevel: 'high',
      reason: 'Archive file (.zip) — may contain malware', blockedAt: new Date(Date.now() - 300000), status: 'quarantined'
    },
    {
      id: '3', fileName: 'report_final.docm', fileType: '.docm', fileSize: 450000,
      sender: 'unknown_user@temp.io', senderType: 'unknown', threatLevel: 'medium',
      reason: 'Macro-enabled document (.docm) — potential threat', blockedAt: new Date(Date.now() - 600000), status: 'blocked'
    },
    {
      id: '4', fileName: 'presentation.pptx', fileType: '.pptx', fileSize: 5200000,
      sender: 'colleague@company.com', senderType: 'known', threatLevel: 'low',
      reason: 'File blocked per security policy — all files require review', blockedAt: new Date(Date.now() - 900000), status: 'reviewed'
    },
    {
      id: '5', fileName: 'payload.bat', fileType: '.bat', fileSize: 1200,
      sender: 'attacker@darkweb.onion', senderType: 'unknown', threatLevel: 'critical',
      reason: 'Executable file type (.bat) — immediate threat', blockedAt: new Date(Date.now() - 45000), status: 'blocked'
    },
  ];
  return demoFiles;
}
